<template>
  <Tutorial />
</template>